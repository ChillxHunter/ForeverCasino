FOREVER CASINO 1.3.0 (WORLD OF WARCRAFT: FOREVER)
=================================================

INSTALL
1. Close WoW Forever.
2. Copy the ForeverCasino folder to:
   World of Warcraft\_forever_\Interface\AddOns\ForeverCasino\
3. Start WoW Forever. Enable Forever Casino in the AddOns menu.
4. Type /casino or /fcasino, or click the draggable minimap icon.
5. Check "I confirm I am 18 years or older" and click Confirm & Enter.
   This is self-attestation only, not verified identification.
6. Two-player games require both players to install version 1.3.0.

GAME MODES
- Coin Toss: best of 1, 3, or 5. One side is Heads, the other Tails.
- Deathroll: alternate server-generated rolls. Begin with d1000;
  each next die has the number of sides equal to the last result.
  Whoever rolls 1 first loses.
- Solo Practice: control both sides, no opponent required.
- Two Players: enter an opponent's character name or select Target.
  Send a challenge; when accepted, BOTH players press Ready.
  A match begins only after both players are ready.
- You may cancel your Ready status until the match begins.
- The game reads the server's normal /roll messages.

CONTROLS
- /casino or /fcasino: open the UI.
- /fcasino icon: show or hide the minimap button.
- Drag the minimap icon to move it around the minimap.

IMPORTANT TECHNICAL LIMITATIONS
- This addon does not handle any transfers, transactions, or value tracking.
- Each opponent must run the same addon version and be able to receive
  addon WHISPER messages. Some game instances limit addon messaging.
- For transparently observed rolls, play nearby or in the same party so
  each player can also check the normal WoW roll messages.
- Remote addon roll packets are not cryptographically authenticated.
- One active match per character. Matches end on logout or /reload.
- Interface 16001 is intended for WoW Forever.
- Native WoW UI only. No executable, external web service or automation.
- The build requires live testing with two real characters.

VERSION 1.3.0
- Redesigned native WoW game-table interface with clickable coin/dice artwork.
- Improved recognition of server /roll messages in Solo Practice.
- Two-player game protocol uses a new version; both players need v1.3.0.
