-- Forever Casino 1.3.0 -- WoW Forever (Interface 16001)
-- Purely recreational Coin Toss and Deathroll games.
-- Game results are taken from the game's own /roll output, not math.random.
local addonName, ns = ...
local A = CreateFrame("Frame")
ns.Core = A
A.version = "1.3.0"
A.prefix = "FCasino3"
A.session = nil
A.status = "Choose a game and challenge a player who has this addon."
A.myName = nil
A.pendingRoll = nil
-- Self-attested age confirmation is required once per login session.
-- This cannot verify someone's identity or actual age.
A.ageConfirmed = false

local floor, tonumber, tostring, tconcat = math.floor, tonumber, tostring, table.concat
local function trim(s) return (tostring(s or ""):match("^%s*(.-)%s*$")) end
local function nameKey(s)
    return trim(s):lower():gsub("%s+", " ")
end
local function shortKey(s)
    return nameKey(s):match("^([^-]+)") or nameKey(s)
end
local function samePlayer(a,b)
    if nameKey(a) == nameKey(b) then return true end
    -- The game sometimes displays rolls with the short name rather than Name-Realm.
    return shortKey(a) == shortKey(b)
end
local function parseParts(message)
    local parts = {}
    for v in (message .. "|"):gmatch("(.-)|") do
        parts[#parts+1] = v
        if #parts > 10 then return {} end
    end
    return parts
end
local function getSelfName()
    local n, realm
    if UnitFullName then n, realm = UnitFullName("player") end
    if not n or n == "" then n = UnitName("player") end
    if realm and realm ~= "" then return n .. "-" .. realm end
    return n or ""
end
function A:Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffc566Forever Casino:|r " .. tostring(msg))
    end
end
function A:Update(message)
    if message then self.status = message end
    if ns.UI and ns.UI.Refresh then ns.UI:Refresh() end
end
function A:Open()
    if ns.UI and ns.UI.Show then ns.UI:Show(true) end
end
function A:ConfirmAge()
    -- Only call from the visible checkbox's explicit confirmation button.
    self.ageConfirmed = true
    self:Update("Age confirmation accepted. Select Solo Practice or challenge another player.")
    if ns.UI and ns.UI.UpdateAgeGate then ns.UI:UpdateAgeGate() end
end
function A:RequireAge()
    if self.ageConfirmed then return true end
    self:Open()
    self:Update("You must explicitly confirm that you are 18 or older to use this addon.")
    return false
end
function A:Transmit(target, data)
    if not target or target == "" then self:Update("No player selected."); return false end
    if not C_ChatInfo or not C_ChatInfo.SendAddonMessage then
        self:Update("Addon messages are not available on this client.")
        return false
    end
    if #data > 255 then return false end
    local ok, result = pcall(C_ChatInfo.SendAddonMessage, self.prefix, data, "WHISPER", target)
    if not ok or result == false or (type(result) == "number" and result ~= 0) then
        self:Update("Unable to send addon whisper. Try again outside instances; both players need the addon.")
        return false
    end
    return true
end
function A:Send(action, rest)
    local s = self.session
    if not s then return false end
    return self:Transmit(s.other, action .. "|" .. s.id .. (rest and ("|" .. rest) or ""))
end
function A:Challenge(opponent, kind, best)
    if not self:RequireAge() then return false end
    if self.session and self.session.stage ~= "done" then
        self:Update("Finish or cancel your current game first.")
        return false
    end
    opponent = trim(opponent)
    if opponent == "" or #opponent > 70 or opponent:find("|",1,true) or opponent:find("/",1,true) then
        self:Update("Enter a valid character name, or use Target.")
        return false
    end
    if samePlayer(opponent, self.myName or getSelfName()) then
        self:Update("Choose another player.")
        return false
    end
    if kind ~= "COIN" and kind ~= "DEATH" then return false end
    best = tonumber(best)
    if kind == "COIN" and best ~= 1 and best ~= 3 and best ~= 5 then return false end
    if kind == "DEATH" then best = 1 end
    local id = tostring(time()) .. tostring(floor(GetTime()*1000) % 1000000)
    local s = {
        id=id, other=opponent, host=true, kind=kind, best=best,
        stage="invite", localReady=false, remoteReady=false, history={},
        scoreHost=0, scoreGuest=0
    }
    self.session = s
    if not self:Send("CHAL", kind .. "|" .. best) then self.session = nil; return false end
    self:Update("Challenge sent to " .. opponent .. ". Both players need Forever Casino installed.")
    return true
end
function A:Accept()
    if not self:RequireAge() then return end
    local s=self.session
    if not s or s.stage ~= "incoming" then return end
    if not self:Send("ACCEPT") then return end
    s.stage="ready"
    self:Update("Challenge accepted. Both players must click Ready to begin.")
end
function A:Decline()
    local s=self.session
    if not s then return end
    if s.solo then
        self.pendingRoll=nil
        self.session=nil
        self:Update("Solo practice closed.")
        return
    end
    self:Send(s.stage == "incoming" and "DECLINE" or "END")
    self.pendingRoll=nil
    self.session=nil
    self:Update("Challenge closed.")
end
function A:Ready()
    if not self:RequireAge() then return end
    local s=self.session
    if not s or s.stage ~= "ready" then return end
    if s.localReady then self:Update("You are already ready."); return end
    if not self:Send("READY") then return end
    s.localReady=true
    self:Update("You are ready. Waiting for the other player.")
    self:MaybeBegin()
end
function A:Unready()
    local s=self.session
    if not s or s.stage ~= "ready" then return end
    if not self:Send("UNREADY") then return end
    s.localReady=false
    self:Update("You are no longer ready.")
end
function A:MaybeBegin()
    local s=self.session
    if not s or s.stage ~= "ready" or not s.host then return end
    if not (s.localReady and s.remoteReady) then return end
    if not self:Send("START") then return end
    self:StartGame()
end
function A:StartSolo(kind,best)
    if not self:RequireAge() then return false end
    if self.session and self.session.stage ~= "done" then
        self:Update("Finish or cancel your current game first.")
        return false
    end
    if kind ~= "COIN" and kind ~= "DEATH" then return false end
    best=tonumber(best)
    if kind == "COIN" and best ~= 1 and best ~= 3 and best ~= 5 then return false end
    if kind == "DEATH" then best = 1 end
    self.session={id="solo", other="Solo Practice", host=true, solo=true,
        kind=kind, best=best, stage="play",
        localReady=true, remoteReady=true, seq=1, limit=1000, turn="host",
        scoreHost=0, scoreGuest=0, history={}}
    self.pendingRoll=nil
    if kind=="COIN" then
        self:Update("Solo Coin Toss: you play both HEADS and TAILS. Flip to see who wins.")
    else
        self:Update("Solo Deathroll: control Side A and Side B alternately. First side to roll 1 loses.")
    end
    return true
end
function A:StartGame()
    local s=self.session
    if not s or s.stage ~= "ready" then return end
    if not (s.localReady and s.remoteReady) then return end
    s.stage="play"
    s.limit=1000
    s.seq=1
    s.turn="host"
    s.scoreHost=0
    s.scoreGuest=0
    s.history={}
    s.winner=nil
    self.pendingRoll=nil
    if s.kind == "COIN" then
        self:Update("Both players are ready. Host flips the coin: heads = host, tails = guest.")
    else
        self:Update("Both players are ready. The challenger rolls d1000 first. Take turns until someone rolls 1.")
    end
end
function A:LocalRole()
    local s=self.session
    return (s and s.host) and "host" or "guest"
end
function A:CanRoll()
    local s=self.session
    if not s or s.stage ~= "play" or self.pendingRoll or not self.ageConfirmed then return false end
    if s.solo then return true end
    if s.kind == "COIN" then return s.host end
    return s.turn == self:LocalRole()
end
function A:Roll()
    if not self:RequireAge() then return end
    local s=self.session
    if not self:CanRoll() then self:Update("It's not your turn, or a roll is still pending."); return end
    if type(RandomRoll) ~= "function" then self:Update("The server /roll function is unavailable."); return end
    local upper = (s.kind == "COIN") and 2 or s.limit
    self.pendingRoll={id=s.id, upper=upper, seq=s.seq, since=GetTime()}
    self:Update("Rolling the server's d" .. upper .. " die...")
    RandomRoll(1, upper)
end
local function parseServerRoll(msg)
    -- Always use the server message; never invent a random result locally.
    -- Client builds and language packs use different roll-message punctuation.
    msg=tostring(msg or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    local fmt=RANDOM_ROLL_RESULT
    if type(fmt)=="string" then
        -- Expand localization tokens *before* quoting Lua pattern punctuation.
        local format=fmt:gsub("%%(%d+)%$([sd])", function(_,kind) return "%"..kind end)
        format=format:gsub("%%s", "CASINOPLAYER")
        local count=0
        format=format:gsub("%%d", function() count=count+1; return "CASINONUMBER"..count end)
        format=format:gsub("([^%w])", "%%%1")
        format=format:gsub("CASINOPLAYER", "(.-)")
        format=format:gsub("CASINONUMBER%d+", "(%%d+)")
        local who,value,low,high=msg:match("^"..format.."$")
        if who and value and low and high then
            return who,tonumber(value),tonumber(low),tonumber(high)
        end
    end
    -- WoW English variants include "Alice rolls 42 (1-1000)" and
    -- "You roll 42 (1 - 1000)". These are server-generated system messages.
    local who,val,low,high=msg:match("^%s*(.-)%s+rolls?%s*:?[ ]*(%d+)%s*%(%s*(%d+)%s*%-%s*(%d+)%s*%)")
    if who and val then return who,tonumber(val),tonumber(low),tonumber(high) end
    -- Format variants may say "You rolled a 42 (1-1000)" or use a local language.
    -- Accept only when the string starts with our character name or "You",
    -- AND precisely matches our outstanding die-size request.
    local value,startDie,endDie=msg:match("(%d+)%s*%(%s*(%d+)%s*%-%s*(%d+)%s*%)")
    if value then
        local prefix=msg:match("^%s*(.-)%d+%s*%(") or ""
        local first=prefix:match("^%s*([^%s]+)") or ""
        local lower=first:lower()
        if lower=="you" or lower=="your" or samePlayer(first,A.myName or getSelfName()) then
            return A.myName or getSelfName(),tonumber(value),tonumber(startDie),tonumber(endDie)
        end
    end
    return nil
end
function A:OnServerRoll(msg)
    local p=self.pendingRoll
    local s=self.session
    if not p or not s or s.id ~= p.id or s.stage ~= "play" then return end
    local who,val,low,high=parseServerRoll(msg)
    if not who then return end
    local speaker=trim(who):lower()
    if speaker~="you" and speaker~="your" and not samePlayer(who,self.myName or getSelfName()) then return end
    if low~=1 or high~=p.upper or not val or val<1 or val>p.upper then return end
    if p.seq ~= s.seq then return end
    self.pendingRoll=nil
    if s.solo then
        if s.kind=="COIN" then self:ApplyFlip(val)
        else self:ApplyDeathroll(s.turn,val) end
        return
    end
    if s.kind == "COIN" then
        if self:Send("FLIP", tostring(s.seq).."|"..val) then self:ApplyFlip(val) end
    else
        if self:Send("ROLL", tostring(s.seq).."|"..tostring(p.upper).."|"..val) then
            self:ApplyDeathroll(self:LocalRole(),val)
        end
    end
end
function A:ApplyFlip(result)
    local s=self.session
    if not s or s.kind ~= "COIN" or s.stage ~= "play" or (result ~= 1 and result ~= 2) then return end
    local isHeads=(result==1)
    if isHeads then s.scoreHost=s.scoreHost+1 else s.scoreGuest=s.scoreGuest+1 end
    local line="Flip "..s.seq..": "..(isHeads and (s.solo and "HEADS (Side A)" or "HEADS (challenger)")
        or (s.solo and "TAILS (Side B)" or "TAILS (opponent)"))
    s.history[#s.history+1]=line
    s.seq=s.seq+1
    local needed=floor(s.best/2)+1
    if s.scoreHost>=needed or s.scoreGuest>=needed then
        self:Finish(s.scoreHost>=needed and "host" or "guest")
    else
        self:Update(line .. ". Next flip ready.")
    end
end
function A:ApplyDeathroll(actor,result)
    local s=self.session
    if not s or s.kind ~= "DEATH" or s.stage ~= "play" then return end
    if actor~=s.turn or result < 1 or result > s.limit then return end
    local who
    if s.solo then
        who=actor=="host" and "Side A (you)" or "Side B (you)"
    else
        who=(actor=="host") and (s.host and (self.myName or "You") or s.other)
            or (s.host and s.other or (self.myName or "You"))
    end
    local line=who.." rolled "..result.." / "..s.limit
    s.history[#s.history+1]=line
    s.seq=s.seq+1
    if result==1 then
        -- The player rolling 1 LOSES.
        self:Finish(actor=="host" and "guest" or "host")
    else
        s.limit=result
        s.turn=(actor=="host") and "guest" or "host"
        self:Update(line .. ". Next player rolls d" .. result .. ".")
    end
end
function A:Finish(winner)
    local s=self.session
    if not s then return end
    s.winner=winner
    s.stage="done"
    if s.solo then
        local side=winner=="host" and "Side A (HEADS)" or "Side B (TAILS)"
        if s.kind=="DEATH" then side=winner=="host" and "Side A" or "Side B" end
        self:Update(side.." won the solo practice game!")
    else
        local meWon=(winner==self:LocalRole())
        self:Update(meWon and "You won the match!" or "You lost the match!")
    end
    self.pendingRoll=nil
end
function A:HandleIncoming(msg,channel,sender)
    if channel~="WHISPER" or type(msg)~="string" or type(sender)~="string" then return end
    local p=parseParts(msg)
    local action,id=p[1],p[2]
    if not id or not id:match("^%d+$") or #id>30 then return end
    if action=="CHAL" then
        local kind, best = p[3], tonumber(p[4])
        if kind~="COIN" and kind~="DEATH" then return end
        if kind=="COIN" and (best~=1 and best~=3 and best~=5) then return end
        if kind=="DEATH" and best~=1 then return end
        if samePlayer(sender,self.myName or getSelfName()) then return end
        if self.session and self.session.stage~="done" then
            self:Transmit(sender,"BUSY|"..id)
            return
        end
        self.session={id=id,other=sender,host=false,kind=kind,best=best,stage="incoming",
            localReady=false,remoteReady=false,
            history={},scoreHost=0,scoreGuest=0}
        self:Open()
        self:Update("Incoming "..(kind=="COIN" and "Coin Toss" or "Deathroll").." challenge from "..sender..". Accept or decline.")
        return
    end
    local s=self.session
    if not s or s.id~=id or not samePlayer(sender,s.other) then return end
    if action=="BUSY" and s.stage=="invite" then
        self.session=nil; self:Update(sender.." is already in another game.")
    elseif action=="DECLINE" and s.stage=="invite" then
        self.session=nil; self:Update(sender.." declined your challenge.")
    elseif action=="ACCEPT" and s.host and s.stage=="invite" then
        s.stage="ready"
        self:Update(sender.." accepted. Both players must click Ready to begin.")
    elseif action=="READY" and s.stage=="ready" then
        s.remoteReady=true
        self:Update(sender.." is ready.")
        self:MaybeBegin()
    elseif action=="UNREADY" and s.stage=="ready" then
        s.remoteReady=false
        self:Update(sender.." is no longer ready.")
    elseif action=="START" and not s.host and s.stage=="ready" then
        if s.localReady and s.remoteReady then
            self:StartGame()
        else
            self:Update("Start rejected: both players must click Ready first.")
        end
    elseif action=="FLIP" and not s.host and s.kind=="COIN" and s.stage=="play" then
        local seq=tonumber(p[3]); local result=tonumber(p[4])
        if seq==s.seq and (result==1 or result==2) then self:ApplyFlip(result) end
    elseif action=="ROLL" and s.kind=="DEATH" and s.stage=="play" then
        local seq,upper,value=tonumber(p[3]),tonumber(p[4]),tonumber(p[5])
        local remoteRole=s.host and "guest" or "host"
        if s.turn==remoteRole and seq==s.seq and upper==s.limit and value and floor(value)==value and value>=1 and value<=upper then
            self:ApplyDeathroll(remoteRole,value)
        end
    elseif action=="END" then
        self.pendingRoll=nil
        s.stage="done"
        s.history[#s.history+1]="Other player closed the game."
        self:Update(sender.." left the table.")
    end
end
function A:OnEvent(event, ...)
    if event=="PLAYER_LOGIN" then
        self.ageConfirmed=false
        self.myName=getSelfName()
        if not ForeverCasinoDB then ForeverCasinoDB={} end
        if ForeverCasinoDB.minimapAngle==nil then ForeverCasinoDB.minimapAngle=225 end
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            C_ChatInfo.RegisterAddonMessagePrefix(self.prefix)
        end
        if ns.UI and ns.UI.Build then ns.UI:Build() end
        self:Update()
    elseif event=="CHAT_MSG_ADDON" then
        local prefix,msg,channel,sender=...
        if prefix==self.prefix then self:HandleIncoming(msg,channel,sender) end
    elseif event=="CHAT_MSG_SYSTEM" then
        self:OnServerRoll((...))
    end
end
A:SetScript("OnEvent", function(_, event, ...) A:OnEvent(event, ...) end)
A:RegisterEvent("PLAYER_LOGIN")
A:RegisterEvent("CHAT_MSG_ADDON")
A:RegisterEvent("CHAT_MSG_SYSTEM")
local elapsedSinceCheck=0
A:SetScript("OnUpdate",function(_,dt)
    elapsedSinceCheck=elapsedSinceCheck+dt
    if elapsedSinceCheck<0.3 then return end
    elapsedSinceCheck=0
    if A.pendingRoll and GetTime()-A.pendingRoll.since>10 then
        local upper=A.pendingRoll.upper
        A.pendingRoll=nil
        A:Update("The server roll was not received. Try Roll again; the expected die was d"..upper..".")
    end
end)
SLASH_FOREVERCASINO1="/casino"
SLASH_FOREVERCASINO2="/fcasino"
SlashCmdList.FOREVERCASINO=function(message)
    if trim(message):lower()=="icon" then
        if not ForeverCasinoDB then ForeverCasinoDB={} end
        ForeverCasinoDB.hideMinimap=not ForeverCasinoDB.hideMinimap
        if ns.UI and ns.UI.UpdateMinimap then ns.UI:UpdateMinimap() end
        A:Print(ForeverCasinoDB.hideMinimap and "Minimap button hidden." or "Minimap button shown.")
    else A:Open() end
end
