-- Forever Casino 1.5: animated LOCAL results and round movable minimap button.
local addonName, ns = ...
local Core, UI = ns.Core, ns.UI
if not Core or not UI then return end
Core.version, Core.prefix = "1.5.0", "FCasino5"
local SPIN, REVEAL = 1.30, 1.05
local function samePerson(a,b)
    if not a or not b then return false end
    a=tostring(a):lower():gsub("%s+","")
    b=tostring(b):lower():gsub("%s+","")
    return a==b or a:match("^[^-]+") == b:match("^[^-]+")
end
local function clamp(v,minimum,maximum) return math.max(minimum,math.min(maximum,v)) end
local function angle(y,x)
    if math.atan2 then return math.atan2(y,x) end
    if x==0 then return y>=0 and math.pi/2 or -math.pi/2 end
    local a=math.atan(y/x)
    return x<0 and a+math.pi or a
end

local oldCanRoll=Core.CanRoll
function Core:CanRoll() return not self.activeEffect and oldCanRoll(self) end
function Core:BeginEffect(actor,maximum,result,isRemote)
    local s=self.session
    if not s or s.stage~="play" or self.activeEffect then return false end
    self.activeEffect={id=s.id,seq=s.seq,kind=s.kind,actor=actor,max=maximum,value=result,
        remote=isRemote,elapsed=0}
    if UI.StartEffect then UI:StartEffect(self.activeEffect) end
    self:Update("Rolling... the result will appear after the animation.")
    return true
end
function Core:TickEffect(dt)
    local e=self.activeEffect
    if not e then return end
    e.elapsed=e.elapsed+math.max(0,dt or 0)
    if UI.AnimateEffect then UI:AnimateEffect(e) end
    if e.elapsed<SPIN+REVEAL then return end
    self.activeEffect=nil
    if UI.StopEffect then UI:StopEffect() end
    local s=self.session
    if not s or s.id~=e.id or s.stage~="play" or s.seq~=e.seq or s.kind~=e.kind then return end
    if e.kind=="COIN" then
        self:ApplyFlip(e.value)
        self:Print("Local coin toss: "..(e.value==1 and "HEADS" or "TAILS").." (not server-verified).")
    else
        self:ApplyDeathroll(e.actor,e.value)
        self:Print((e.actor=="host" and "Side A" or "Side B").." rolled "..e.value..
            " (1-"..e.max..") [local result, not server-verified]")
    end
end
function Core:Roll()
    if not self:RequireAge() then return end
    local s=self.session
    if not self:CanRoll() then self:Update("Wait for your turn or for the current animation."); return end
    local now=GetTime and GetTime() or 0
    if now<(self.nextRollAt or 0) then return end
    local maximum=s.kind=="COIN" and 2 or s.limit
    local result=self:LocalRandom(maximum)
    if not result then self:Update("Invalid die size."); return end
    if not s.solo then
        local ok
        if s.kind=="COIN" then ok=self:Send("FLIP",s.seq.."|"..result)
        else ok=self:Send("ROLL",s.seq.."|"..maximum.."|"..result) end
        if not ok then return end
    end
    self.nextRollAt=now+0.2
    self:BeginEffect(s.solo and s.turn or self:LocalRole(),maximum,result,false)
end
local oldIncoming=Core.HandleIncoming
function Core:HandleIncoming(message,channel,sender)
    if channel=="WHISPER" and type(message)=="string" and type(sender)=="string" then
        local s=self.session
        if s and s.stage=="play" and not s.solo and not self.activeEffect and samePerson(sender,s.other) then
            local id,seq,result=message:match("^FLIP|([^|]+)|(%d+)|(%d+)$")
            if id and id==s.id and not s.host and s.kind=="COIN" and tonumber(seq)==s.seq
                and (tonumber(result)==1 or tonumber(result)==2) then
                self:BeginEffect("host",2,tonumber(result),true)
                return
            end
            local rid,rseq,maximum,value=message:match("^ROLL|([^|]+)|(%d+)|(%d+)|(%d+)$")
            if rid and rid==s.id and s.kind=="DEATH" and tonumber(rseq)==s.seq
                and tonumber(maximum)==s.limit and tonumber(value)>=1 and tonumber(value)<=s.limit then
                local actor=s.host and "guest" or "host"
                if actor==s.turn then self:BeginEffect(actor,s.limit,tonumber(value),true);return end
            end
        end
        -- Do not allow the old instant-apply handler to bypass animation on
        -- duplicate, stale or maliciously repeated roll messages.
        if message:sub(1,5)=="ROLL|" or message:sub(1,5)=="FLIP|" then return end
    end
    return oldIncoming(self,message,channel,sender)
end
local oldDecline=Core.Decline
function Core:Decline(...)
    self.activeEffect=nil;if UI.StopEffect then UI:StopEffect() end
    return oldDecline(self,...)
end
local oldSolo=Core.StartSolo
function Core:StartSolo(...)
    self.activeEffect=nil;if UI.StopEffect then UI:StopEffect() end
    return oldSolo(self,...)
end
local oldStart=Core.StartGame
function Core:StartGame(...)
    self.activeEffect=nil;if UI.StopEffect then UI:StopEffect() end
    return oldStart(self,...)
end
local oldDraw=Core.OfferDraw
function Core:OfferDraw(...)
    if self.activeEffect then self:Update("Wait until the current roll finishes.");return end
    return oldDraw(self,...)
end
Core:SetScript("OnUpdate",function(_,dt) Core:TickEffect(dt) end)

-- Minimap icon: transparent round artwork, normal click opens UI; ALT+drag moves
-- the icon outside the minimap boundary and preserves the radius and angle.
function UI:UpdateMinimap()
    if not self.minimap or not Minimap then return end
    local db=type(ForeverCasinoDB)=="table" and ForeverCasinoDB or {}
    self.minimap:SetShown(not db.hideMinimap)
    local limit=math.max(Minimap:GetWidth() or 140,Minimap:GetHeight() or 140)/2+12
    local radius=clamp(db.minimapRadius or (limit+8),limit,limit+85)
    local theta=math.rad(db.minimapAngle or 225)
    self.minimap:ClearAllPoints()
    self.minimap:SetPoint("CENTER",Minimap,"CENTER",math.cos(theta)*radius,math.sin(theta)*radius)
end
function UI:BuildMinimap()
    if not Minimap then return end
    if self.minimap then self:UpdateMinimap();return end
    local m=CreateFrame("Button","ForeverCasinoMinimapButton",Minimap)
    m:SetSize(38,38);m:SetFrameStrata("HIGH")
    m:RegisterForClicks("LeftButtonUp");m:RegisterForDrag("LeftButton")
    local icon=m:CreateTexture(nil,"ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture("Interface\\AddOns\\ForeverCasino\\Media\\MinimapCasino.tga")
    icon:SetAlpha(.95);m.icon=icon
    m:SetScript("OnClick",function(self)
        if self.ignoreClick then self.ignoreClick=false;return end
        if IsAltKeyDown and IsAltKeyDown() then return end
        UI:Toggle()
    end)
    m:SetScript("OnEnter",function(self)
        self.icon:SetAlpha(1)
        if GameTooltip then
            GameTooltip:SetOwner(self,"ANCHOR_LEFT")
            GameTooltip:AddLine("Forever Casino",1,.78,.30)
            GameTooltip:AddLine("Click: open/close",1,1,1)
            GameTooltip:AddLine("ALT + drag: move outside minimap circle",.7,.8,1)
            GameTooltip:Show()
        end
    end)
    m:SetScript("OnLeave",function(self)
        self.icon:SetAlpha(.95)
        if GameTooltip then GameTooltip:Hide() end
    end)
    m:SetScript("OnDragStart",function(self)
        if not (IsAltKeyDown and IsAltKeyDown()) then return end
        self.ignoreClick=true
        self:SetScript("OnUpdate",function()
            if not (IsAltKeyDown and IsAltKeyDown()) then return end
            if type(ForeverCasinoDB)~="table" then ForeverCasinoDB={} end
            local scale=(Minimap.GetEffectiveScale and Minimap:GetEffectiveScale()) or 1
            if scale<=0 then scale=1 end
            local cx,cy=Minimap:GetCenter()
            local x,y=GetCursorPosition()
            if not cx or not cy or not x or not y then return end
            local dx,dy=x/scale-cx,y/scale-cy
            local minR=math.max(Minimap:GetWidth() or 140,Minimap:GetHeight() or 140)/2+12
            ForeverCasinoDB.minimapRadius=clamp(math.sqrt(dx*dx+dy*dy),minR,minR+85)
            ForeverCasinoDB.minimapAngle=math.deg(angle(dy,dx))
            UI:UpdateMinimap()
        end)
    end)
    m:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil)end)
    self.minimap=m
    self:UpdateMinimap()
end
function UI:EnsureMinimapButton()
    if not self.built or not Minimap then return end
    if not self.minimap then self:BuildMinimap() end
    if self.minimap then
        self.minimap:SetSize(38,38)
        self.minimap:SetFrameStrata("HIGH")
        if Minimap.GetFrameLevel then self.minimap:SetFrameLevel(Minimap:GetFrameLevel()+8) end
        self:UpdateMinimap()
    end
end

-- Presentation overlay. The pending result does not update scores or chat until
-- the number has been displayed for a full reveal interval.
function UI:BuildEffect()
    if self.effect then return end
    local frame=CreateFrame("Frame","ForeverCasinoResultEffect",UIParent,"BackdropTemplate")
    frame:SetSize(430,250)
    frame:SetPoint("CENTER",UIParent,"CENTER",0,70)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:EnableMouse(false)
    frame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",
        edgeSize=2,insets={left=2,right=2,top=2,bottom=2}})
    frame:SetBackdropColor(.014,.02,.045,.94)
    frame:SetBackdropBorderColor(1,.74,.3,1)
    local art=frame:CreateTexture(nil,"ARTWORK")
    art:SetPoint("CENTER",frame,"CENTER",0,48)
    art:SetSize(88,88)
    frame.art=art
    local title=frame:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOP",frame,"TOP",0,-18)
    title:SetTextColor(1,.79,.34)
    frame.title=title
    local num=frame:CreateFontString(nil,"OVERLAY","GameFontNormalHuge")
    num:SetPoint("CENTER",frame,"CENTER",0,-24)
    num:SetSize(400,105)
    num:SetJustifyH("CENTER")
    num:SetTextColor(1,1,.95)
    if num.SetFont then num:SetFont("Fonts\\FRIZQT__.TTF",76,"OUTLINE") end
    frame.num=num
    local footer=frame:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    footer:SetPoint("BOTTOM",frame,"BOTTOM",0,17)
    footer:SetTextColor(.67,.8,1)
    frame.footer=footer
    frame:Hide();self.effect=frame
end
function UI:StartEffect(e)
    if not self.effect then self:BuildEffect() end
    local f=self.effect
    f.art:SetTexture(e.kind=="COIN" and "Interface\\Icons\\INV_Misc_Coin_02"
        or "Interface\\Icons\\INV_Misc_Dice_01")
    f.title:SetText(e.kind=="COIN" and "FLIPPING THE COIN" or "ROLLING THE DIE")
    f.num:SetText("...")
    f.footer:SetText("RESULT REVEAL COMING UP")
    f:SetAlpha(1);f:Show()
end
function UI:AnimateEffect(e)
    local f=self.effect
    if not f then return end
    if e.elapsed<SPIN then
        local fake=(math.floor(e.elapsed*2451)+math.floor(e.elapsed*93)*127)%e.max+1
        f.num:SetText(e.kind=="COIN" and (math.floor(e.elapsed*12)%2==0 and "HEADS" or "TAILS") or tostring(fake))
        f.num:SetTextColor(.91,.89,1)
        f.title:SetText(e.kind=="COIN" and "FLIPPING THE COIN" or "ROLLING THE DIE")
        f.footer:SetText("YOUR RESULT IS COMING...")
        if f.art.SetRotation then f.art:SetRotation(e.elapsed*14) end
        local pulse=84+math.abs(math.sin(e.elapsed*15))*20
        f.art:SetSize(pulse,pulse)
    else
        if f.art.SetRotation then f.art:SetRotation(0) end
        f.art:SetSize(100,100)
        f.title:SetText("THE RESULT IS...")
        f.num:SetText(e.kind=="COIN" and (e.value==1 and "HEADS" or "TAILS") or tostring(e.value))
        f.num:SetTextColor(1,.78,.30)
        f.footer:SetText(e.kind=="COIN" and "COIN TOSS COMPLETE" or ("LOCAL RESULT / d"..e.max))
        f:SetAlpha(clamp((SPIN+REVEAL-e.elapsed)/.25,0,1))
    end
end
function UI:StopEffect() if self.effect then self.effect:Hide() end end

local originalRefresh=UI.Refresh
function UI:Refresh(...)
    originalRefresh(self,...)
    if Core.activeEffect then
        if self.main and self.main:IsShown() then self.main:SetEnabled(false) end
        if self.secondary and self.secondary:IsShown() then self.secondary:SetEnabled(false) end
        if self.turnFlag then self.turnFlag:SetText("ROLLING — WAIT FOR REVEAL") end
        if self.symbolHelp then self.symbolHelp:SetText("ANIMATION IN PROGRESS") end
    end
end
local originalBuild=UI.Build
function UI:Build(...)
    if self.built then return end
    originalBuild(self,...)
    self:BuildEffect()
    if self.frame and self.frame.GetRegions then
        local n=select("#",self.frame:GetRegions())
        for i=1,n do
            local region=select(i,self.frame:GetRegions())
            if region and region.GetText and region.IsObjectType and region:IsObjectType("FontString") then
                local t=region:GetText()
                if t=="V 1.4.0" or t=="V 1.4.1" then region:SetText("V 1.5.0") end
            end
        end
    end
    self:EnsureMinimapButton()
end
